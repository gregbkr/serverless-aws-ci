# SAM Serverless Lambda function

## Overview
Gitlab-ci will create 2 Lambda apps (javascript + python3) and get a domain url via Apigateway + route53.

I used this [tuto](https://docs.gitlab.com/ee/user/project/clusters/serverless/aws.html#aws-serverless-application-model).


## Deploy

### Requisit

- Optional: create a certificate for this API e.g.: `*.api.demo.cloudlabs.link`
- Need gitlab var `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` for ci to deploy to AWS.
- First create the IAM user with: 
```
cd terraform
nano main.tf <-- edit with your needs
terraform init
terraform apply
```
- You will get the value from the output.

### Creates serverless files
- Init: `sam init -r python3.8 -n gitlabpoc --app-template "hello-world"`
- Move files to root: `mv gitlabpoc/* .`

### Deploy manually
Deploy with:
```
sam build
sam package --output-template-file packaged.yaml --s3-bucket sam-serverless-demo-lambda
sam deploy --template-file packaged.yaml --stack-name sam-demo --s3-bucket sam-serverless-demo-lambda --capabilities CAPABILITY_IAM --region eu-west-1
```

To deploy to all component another environment, in DEV, change the `stack-name` user:
`sam deploy --template-file packaged.yaml --stack-name sam-demo-develop --s3-bucket sam-serverless-demo-lambda --capabilities CAPABILITY_IAM --region eu-west-1 --parameter-overrides DomainName=develop.api.demo.cloudlabs.link`

Test with your own URL and API key (you will find the key in aws console apigateway -> apikeys): 
```
curl -H "x-api-key: nM89m9UsGv4SoxntuILms5wcghkREYvY25g77CtB" https://a18qribs8i.execute-api.eu-west-1.amazonaws.com/Prod/hello/
{"message": "hello world"}%
```


### Deploy via CI
- Edit ci with your needs: `nano .gitlab-ci.yml`
- Push file

### Check values
aws cloudformation describe-stacks --stack-name gitlabpoc --region eu-west-1 \
    --query 'Stacks[0].Outputs[?OutputKey==`ServerlessApiKey`].OutputValue' \
    --output text

## Destroy all
- Destroy using the right region: `aws cloudformation delete-stack --stack-name sam-demo-develop --region eu-west-1`

Todo:
- [x] Secure with APIkey
- [x] Dev + Prod
- [x] Ci create + delete stack
- [x] Add route53 domain + Cert
  